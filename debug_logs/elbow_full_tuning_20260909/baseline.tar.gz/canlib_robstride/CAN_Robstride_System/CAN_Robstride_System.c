/*
 * CAN_Robstride_System.c
 */

// Includes --------------------------------

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <CAN_Robstride_Def.h>
#include <CAN_Robstride_System.h>
#include <robstride_constant.h>

// Variables --------------------------------

CAN_HandleTypeDef *_robstride_phcan_global; // 変更しない事
CAN_RingBuf_Robstride robstride_can_buf_ring1 = { 0 };
static CAN_PriorityRingBuf_Robstride robstride_can_priority_buf_ring1 = { 0 };
robstride_feedback_data_raw _robstride_feedback_data_raw_global[129];
Robstride_FeedbackData robstride_fb_data_global[129];

/* A Type 2 frame has no command sequence number.  These counters let the
 * service transaction require a frame received after its own request. */
static volatile uint32_t robstride_feedback_sequence[129];
static volatile float arm_measured_position[129];
static volatile uint32_t arm_position_tick[129];
static volatile bool arm_position_valid[129];
static volatile Robstride_StandardFeedback robstride_standard_feedback[129];

bool Robstride_UsesStandardFeedback(const Robstride_DeviceInfo *device)
{
    /* Mode5は位置MPC実装時にこの共通経路へ接続する。現在はサービス未公開。 */
    return device && device->ctrl_param._enable_flag &&
           device->ctrl_param.ctrl_type==ROBSTRIDE_CTRL_VEL_DOB;
}

bool Robstride_ReadStandardFeedback(const Robstride_DeviceInfo *device, Robstride_StandardFeedback *feedback)
{
    if (!device || !feedback || device->device_id>=129U) return false;
    const uint32_t mask=__get_PRIMASK();
    __disable_irq();
    *feedback=robstride_standard_feedback[device->device_id];
    __set_PRIMASK(mask);
    return feedback->valid;
}

float Robstride_StandardReferenceCurrent(const Robstride_DeviceInfo *device, const Robstride_StandardFeedback *feedback)
{
    if (!device || !feedback || !feedback->valid) return NAN;
    switch (device->device) {
        case Robstride_02: return feedback->torque/1.22f;
        case Robstride_05_Edu: return feedback->torque/0.94f;
        default: return NAN;
    }
}

typedef struct {
    volatile uint32_t run_mode;
    volatile uint32_t iq_ref;
    volatile uint32_t speed_ref;
    volatile uint32_t loc_ref;
    volatile uint32_t cur_kp, cur_ki, cur_filt_gain;
} RobstrideParameterSequence;

static RobstrideParameterSequence robstride_parameter_sequence[129];

/* Type 17 replies carry the destination master ID in the low byte of the
 * extended ID.  Remember the master ID configured for each motor so a frame
 * belonging to another CAN master cannot advance a service wait sequence. */
static volatile uint8_t robstride_parameter_master_id[129];
static volatile uint8_t robstride_parameter_master_id_valid[129];

/* While non-zero, normal target/Get frames remain queued and cannot occupy a
 * newly freed CAN mailbox ahead of a service transaction. */
static volatile uint8_t robstride_priority_transaction_depth = 0U;

/* Fault frames can be repeated continuously.  Keep the last code per motor so
 * a persistent fault cannot flood the serial link and starve micro-ROS. */
static uint32_t robstride_last_fault_code[129];
static uint32_t robstride_last_warning_code[129];

/*
 * Runtime diagnostics.  They are incremented from both task and CAN ISR
 * contexts and consumed periodically by the Robstride task.
 */
static volatile uint32_t robstride_tx_ring_overrun_count = 0U;
static volatile uint32_t robstride_tx_error_count = 0U;
static volatile uint32_t robstride_priority_queue_full_count = 0U;
static volatile uint32_t robstride_can_error_count = 0U;
static volatile uint32_t robstride_can_error_code = HAL_CAN_ERROR_NONE;
static volatile Robstride_RateCounters robstride_rate_counters;
static uint32_t robstride_target_last_tick[2];

Robstride_RateCounters Robstride_TakeRateCounters(void)
{
    const uint32_t primask=__get_PRIMASK();
    __disable_irq();
    Robstride_RateCounters result=robstride_rate_counters;
    robstride_rate_counters=(Robstride_RateCounters){0};
    __set_PRIMASK(primask);
    return result;
}

// Private Function Prototypes --------------------------------

static float uint_to_float(uint16_t x, float x_min, float x_max);
static HAL_StatusTypeDef _Robstride_PushTx8Bytes(CAN_RingBuf_Robstride *p_can_ring, uint32_t ExtId, const uint8_t *bytes, uint32_t size);
static HAL_StatusTypeDef _Robstride_PushPriorityTx8Bytes(CAN_PriorityRingBuf_Robstride *p_can_ring, uint32_t ExtId, const uint8_t *bytes, uint32_t size);
static HAL_StatusTypeDef _Robstride_PopSendTx8Bytes(CAN_HandleTypeDef *phcan);
static void Robstride_set_fb_data_raw(uint32_t ExtID, const uint8_t rxData[], uint8_t device_id);
static bool _Robstride_RingHasData(uint32_t read_point, uint32_t write_point, uint8_t is_full);
static void _Robstride_ClearPriorityRing(void);
static void _Robstride_ClearNormalRing(void);
static void _Robstride_DiscardPendingRx(CAN_HandleTypeDef *phcan);
static void _Robstride_RegisterParameterMasterId(const Robstride_DeviceInfo *device_info);
static HAL_StatusTypeDef _Robstride_SendBytesToQueue(CAN_HandleTypeDef *phcan,
                                                       uint8_t motor_id,
                                                       uint8_t cmd_id,
                                                       uint16_t option,
                                                       const uint8_t *bytes,
                                                       uint32_t size,
                                                       bool priority);

static uint32_t robstride_take_counter(volatile uint32_t *counter)
{
    const uint32_t primask = __get_PRIMASK();
    uint32_t value;

    __disable_irq();
    value = *counter;
    *counter = 0U;
    __set_PRIMASK(primask);
    return value;
}

static uint32_t robstride_take_error_code(void)
{
    const uint32_t primask = __get_PRIMASK();
    uint32_t value;

    __disable_irq();
    value = robstride_can_error_code;
    robstride_can_error_code = HAL_CAN_ERROR_NONE;
    __set_PRIMASK(primask);
    return value;
}


// Functions --------------------------------

static float uint_to_float(const uint16_t x, const float x_min, const float x_max) {
    const uint16_t type_max = 0xFFFF;
    const float span = x_max - x_min;
    return (float)x / type_max * span + x_min;
}

static HAL_StatusTypeDef _Robstride_PushTx8Bytes(CAN_RingBuf_Robstride *const p_can_ring, const uint32_t ExtId, const uint8_t *const bytes, const uint32_t size) {
    const uint32_t primask = __get_PRIMASK();

    /* The same ring is drained from CAN TX interrupts. */
    __disable_irq();
    p_can_ring->buffer[p_can_ring->write_point].DLC = size;
    p_can_ring->buffer[p_can_ring->write_point].ExtId = ExtId;
    for (uint8_t i = 0; i < size; i++) p_can_ring->buffer[p_can_ring->write_point].bytes[i] = bytes[i];

    if (p_can_ring->is_full == 1) {
        /* Keep the newest command.  Old queued frames are disposable. */
        ++robstride_tx_ring_overrun_count;
        p_can_ring->read_point = ((p_can_ring->read_point) + 1) & (CAN_TXBUFFER_SIZE - 1);
    }
    p_can_ring->write_point = ((p_can_ring->write_point) + 1) & (CAN_TXBUFFER_SIZE - 1);

    if (p_can_ring->write_point == p_can_ring->read_point) {
        p_can_ring->is_full = 1;
    }
    __set_PRIMASK(primask);
    return HAL_OK;
}

static HAL_StatusTypeDef _Robstride_PushPriorityTx8Bytes(CAN_PriorityRingBuf_Robstride *const p_can_ring,
                                                          const uint32_t ExtId,
                                                          const uint8_t *const bytes,
                                                          const uint32_t size) {
    const uint32_t primask = __get_PRIMASK();

    /* Unlike the normal latest-value queue, a service frame is never
     * overwritten.  The caller must retry when the queue is full. */
    __disable_irq();
    if (p_can_ring->is_full != 0U) {
        ++robstride_priority_queue_full_count;
        __set_PRIMASK(primask);
        return HAL_BUSY;
    }

    p_can_ring->buffer[p_can_ring->write_point].DLC = size;
    p_can_ring->buffer[p_can_ring->write_point].ExtId = ExtId;
    for (uint8_t i = 0U; i < size; ++i) {
        p_can_ring->buffer[p_can_ring->write_point].bytes[i] = bytes[i];
    }
    p_can_ring->write_point =
        (p_can_ring->write_point + 1U) & (CAN_PRIORITY_TXBUFFER_SIZE - 1U);
    if (p_can_ring->write_point == p_can_ring->read_point) {
        p_can_ring->is_full = 1U;
    }
    __set_PRIMASK(primask);
    return HAL_OK;
}

static bool _Robstride_RingHasData(const uint32_t read_point,
                                   const uint32_t write_point,
                                   const uint8_t is_full) {
    return (is_full != 0U) || (read_point != write_point);
}

static HAL_StatusTypeDef _Robstride_PopSendTx8Bytes(CAN_HandleTypeDef *const phcan) {
    CAN_TxHeaderTypeDef txHeader;
    uint32_t txMailbox;
    HAL_StatusTypeDef result = HAL_OK;
    const uint32_t primask = __get_PRIMASK();

    txHeader.RTR = CAN_RTR_DATA;
    txHeader.IDE = CAN_ID_EXT; // 拡張フォーマット
    txHeader.TransmitGlobalTime = DISABLE;

    /* Keep the ring state consistent with the producer task. */
    /* bxCANの送信メールボックスは3個。異常時も無限ループさせない。 */
    uint8_t submitted = 0U;
    __disable_irq();
    while ((submitted < CAN_TX_MAILBOX_COUNT) &&
           (HAL_CAN_GetTxMailboxesFreeLevel(phcan) > 0U)) {
        CANTxBuf_Robstride *frame_buffer;
        uint32_t *read_point;
        uint8_t *is_full;
        uint32_t ring_size;
        bool priority_frame;

        /* Always select service traffic first.  During a transaction normal
         * traffic is held in software so it cannot consume a free mailbox. */
        if (_Robstride_RingHasData(robstride_can_priority_buf_ring1.read_point,
                                   robstride_can_priority_buf_ring1.write_point,
                                   robstride_can_priority_buf_ring1.is_full)) {
            frame_buffer = robstride_can_priority_buf_ring1.buffer;
            read_point = &robstride_can_priority_buf_ring1.read_point;
            is_full = &robstride_can_priority_buf_ring1.is_full;
            ring_size = CAN_PRIORITY_TXBUFFER_SIZE;
            priority_frame = true;
        } else if (robstride_priority_transaction_depth == 0U &&
                   _Robstride_RingHasData(robstride_can_buf_ring1.read_point,
                                          robstride_can_buf_ring1.write_point,
                                          robstride_can_buf_ring1.is_full)) {
            frame_buffer = robstride_can_buf_ring1.buffer;
            read_point = &robstride_can_buf_ring1.read_point;
            is_full = &robstride_can_buf_ring1.is_full;
            ring_size = CAN_TXBUFFER_SIZE;
            priority_frame = false;
        } else {
            break;
        }

        txHeader.DLC = frame_buffer[*read_point].DLC;
        txHeader.StdId = 0; // 標準IDは使わない
        txHeader.ExtId = frame_buffer[*read_point].ExtId;

        HAL_StatusTypeDef ret = HAL_CAN_AddTxMessage(phcan,
                                                     &txHeader,
                                                     frame_buffer[*read_point].bytes,
                                                     &txMailbox);
        if (ret != HAL_OK) {
            ++robstride_tx_error_count;
            /* A service frame must remain pending.  Normal frames are
             * disposable latest-value traffic and retain the old behavior. */
            if (!priority_frame) {
                *read_point = (*read_point + 1U) & (ring_size - 1U);
                *is_full = 0U;
            }
            result = ret;
            break;
        }
        /* HAL受付と実送信完了は別に数える。制御値やキュー順序は変えない。 */
        const uint8_t id=(uint8_t)txHeader.ExtId;
        const uint8_t *data=frame_buffer[*read_point].bytes;
        const uint16_t address=(uint16_t)data[0] | ((uint16_t)data[1]<<8);
        if ((id==1U || id==2U) && (txHeader.ExtId>>24)==CMD_RAM_WRITE &&
            (address==ADDR_IQ_REF || address==ADDR_LOC_REF || address==ADDR_SPEED_REF)) {
            const uint32_t index=id-1U, now=HAL_GetTick();
            const uint32_t gap=now-robstride_target_last_tick[index];
            if (robstride_target_last_tick[index]!=0U && gap>robstride_rate_counters.target_max_gap_ms[index])
                robstride_rate_counters.target_max_gap_ms[index]=gap;
            robstride_target_last_tick[index]=now;
            ++robstride_rate_counters.target_submit[index];
        }
        *read_point = (*read_point + 1U) & (ring_size - 1U);
        *is_full = 0U;
        ++submitted;
    }
    __set_PRIMASK(primask);
    return result;
}

static HAL_StatusTypeDef _Robstride_SendBytesToQueue(CAN_HandleTypeDef *const phcan,
                                                       const uint8_t motor_id,
                                                       const uint8_t cmd_id,
                                                       const uint16_t option,
                                                       const uint8_t *const bytes,
                                                       const uint32_t size,
                                                       const bool priority) {
    const uint32_t quotient = size / 8U;
    const uint32_t remainder = size - (8U * quotient);
    HAL_StatusTypeDef ret;
    const uint32_t ExtId = ((uint32_t)cmd_id << 24) |
                           ((uint32_t)option << 8) |
                           (uint32_t)motor_id;

    for (uint32_t i = 0U; i < quotient; ++i) {
        ret = priority
                  ? _Robstride_PushPriorityTx8Bytes(&robstride_can_priority_buf_ring1,
                                                    ExtId,
                                                    bytes + i * 8U,
                                                    8U)
                  : _Robstride_PushTx8Bytes(&robstride_can_buf_ring1,
                                            ExtId,
                                            bytes + i * 8U,
                                            8U);
        if (ret != HAL_OK) {
            return ret;
        }
    }

    if (remainder != 0U) {
        ret = priority
                  ? _Robstride_PushPriorityTx8Bytes(&robstride_can_priority_buf_ring1,
                                                    ExtId,
                                                    bytes + quotient * 8U,
                                                    remainder)
                  : _Robstride_PushTx8Bytes(&robstride_can_buf_ring1,
                                            ExtId,
                                            bytes + quotient * 8U,
                                            remainder);
        if (ret != HAL_OK) {
            return ret;
        }
    }

    /* If no mailbox is free this still returns HAL_OK: the frame is retained
     * in the appropriate queue and a completion/error interrupt will retry. */
    return _Robstride_PopSendTx8Bytes(phcan);
}

static void _Robstride_ClearPriorityRing(void)
{
    const uint32_t primask = __get_PRIMASK();
    __disable_irq();
    robstride_can_priority_buf_ring1.read_point = 0U;
    robstride_can_priority_buf_ring1.write_point = 0U;
    robstride_can_priority_buf_ring1.is_full = 0U;
    __set_PRIMASK(primask);
}

static void _Robstride_ClearNormalRing(void)
{
    const uint32_t primask = __get_PRIMASK();
    __disable_irq();
    robstride_can_buf_ring1.read_point = 0U;
    robstride_can_buf_ring1.write_point = 0U;
    robstride_can_buf_ring1.is_full = 0U;
    __set_PRIMASK(primask);
}

static void _Robstride_RegisterParameterMasterId(
    const Robstride_DeviceInfo *const device_info)
{
    if (device_info == NULL || device_info->device_id >= 129U) {
        return;
    }

    const uint32_t primask = __get_PRIMASK();
    __disable_irq();
    robstride_parameter_master_id[device_info->device_id] = device_info->master_id;
    robstride_parameter_master_id_valid[device_info->device_id] = 1U;
    __set_PRIMASK(primask);
}

static void _Robstride_DiscardPendingRx(CAN_HandleTypeDef *const phcan)
{
    CAN_RxHeaderTypeDef rx_header;
    uint8_t rx_data[8];
    const uint32_t primask = __get_PRIMASK();

    /* A Type 2 response that was already waiting before the transaction must
     * not satisfy the transaction's fresh-feedback fence. */
    __disable_irq();
    while (HAL_CAN_GetRxFifoFillLevel(phcan, CAN_RX_FIFO0) > 0U) {
        if (HAL_CAN_GetRxMessage(phcan, CAN_RX_FIFO0, &rx_header, rx_data) != HAL_OK) {
            break;
        }
    }
    while (HAL_CAN_GetRxFifoFillLevel(phcan, CAN_RX_FIFO1) > 0U) {
        if (HAL_CAN_GetRxMessage(phcan, CAN_RX_FIFO1, &rx_header, rx_data) != HAL_OK) {
            break;
        }
    }
    __set_PRIMASK(primask);
}

void Robstride_BeginPriorityTransaction(CAN_HandleTypeDef *const phcan)
{
    if (_robstride_phcan_global != phcan) {
        return;
    }

    const uint32_t primask = __get_PRIMASK();
    bool first_transaction;
    __disable_irq();
    first_transaction = (robstride_priority_transaction_depth == 0U);
    if (robstride_priority_transaction_depth < 0xFFU) {
        ++robstride_priority_transaction_depth;
    }
    __set_PRIMASK(primask);

    if (first_transaction) {
        /* Remove already-loaded normal Type 1/17 frames from the hardware
         * mailboxes before a service sequence starts.  Also discard old
         * latest-value frames still queued in software; they must not be
         * released immediately after a mode/enable service finishes. */
        _Robstride_ClearNormalRing();
        _Robstride_ClearPriorityRing();
        _Robstride_DiscardPendingRx(phcan);
        (void)HAL_CAN_AbortTxRequest(phcan,
                                     CAN_TX_MAILBOX0 |
                                     CAN_TX_MAILBOX1 |
                                     CAN_TX_MAILBOX2);
    }
}

void Robstride_EndPriorityTransaction(CAN_HandleTypeDef *const phcan)
{
    if (_robstride_phcan_global != phcan) {
        return;
    }

    const uint32_t primask = __get_PRIMASK();
    bool last_transaction = false;
    __disable_irq();
    if (robstride_priority_transaction_depth > 0U) {
        --robstride_priority_transaction_depth;
        last_transaction = (robstride_priority_transaction_depth == 0U);
    }
    __set_PRIMASK(primask);

    if (last_transaction) {
        (void)_Robstride_PopSendTx8Bytes(phcan);
    }
}

void Robstride_ClearPriorityTxQueue(CAN_HandleTypeDef *const phcan)
{
    if (_robstride_phcan_global != phcan) {
        return;
    }

    _Robstride_ClearPriorityRing();
    _Robstride_DiscardPendingRx(phcan);
    /* A queued high-priority frame may already be in a hardware mailbox.  It
     * must not appear later after the service has returned failure/success. */
    (void)HAL_CAN_AbortTxRequest(phcan,
                                 CAN_TX_MAILBOX0 |
                                 CAN_TX_MAILBOX1 |
                                 CAN_TX_MAILBOX2);
}

HAL_StatusTypeDef Robstride_RequestReadParameter(Robstride_DeviceInfo *const device_info,
                                                  const uint16_t address) {
    if (device_info == NULL || device_info->phcan == NULL) {
        return HAL_ERROR;
    }

    uint8_t can_data[8] = {0U};
    _Robstride_RegisterParameterMasterId(device_info);
    can_data[0] = address & 0x00FF;
    can_data[1] = address >> 8;
    uint16_t option = 0x00 << 8 | device_info->master_id;
    return Robstride_SendBytes(device_info->phcan,
                               device_info->device_id,
                               CMD_RAM_READ,
                               option,
                               can_data,
                               sizeof(can_data));
}

HAL_StatusTypeDef Robstride_RequestReadParameterPriority(Robstride_DeviceInfo *const device_info,
                                                          const uint16_t address) {
    uint8_t can_data[8] = {0U};
    _Robstride_RegisterParameterMasterId(device_info);
    can_data[0] = address & 0x00FFU;
    can_data[1] = (uint8_t)(address >> 8);
    const uint16_t option = device_info->master_id;
    return Robstride_SendPriorityBytes(device_info->phcan,
                                       device_info->device_id,
                                       CMD_RAM_READ,
                                       option,
                                       can_data,
                                       sizeof(can_data));
}

HAL_StatusTypeDef Robstride_WriteFloatData(Robstride_DeviceInfo *const device_info,
                                           const uint16_t address,
                                           const float data) {
    if (device_info == NULL || device_info->phcan == NULL || !isfinite(data)) {
        return HAL_ERROR;
    }

    uint8_t can_data[8] = { 0x00 };
    can_data[0] = address & 0x00FF;
    can_data[1] = address >> 8;
    memcpy(&can_data[4], &data, 4);
    return Robstride_SendBytes(device_info->phcan,
                               device_info->device_id,
                               CMD_RAM_WRITE,
                               device_info->master_id,
                               can_data,
                               sizeof(can_data));
}

HAL_StatusTypeDef Robstride_WriteFloatDataPriority(Robstride_DeviceInfo *const device_info,
                                                    const uint16_t address,
                                                    const float data) {
    uint8_t can_data[8] = {0U};
    can_data[0] = address & 0x00FFU;
    can_data[1] = (uint8_t)(address >> 8);
    memcpy(&can_data[4], &data, sizeof(data));
    return Robstride_SendPriorityBytes(device_info->phcan,
                                       device_info->device_id,
                                       CMD_RAM_WRITE,
                                       device_info->master_id,
                                       can_data,
                                       sizeof(can_data));
}

void Robstride_WriteIntData(Robstride_DeviceInfo *const device_info, const uint16_t address, const int data) {
    uint8_t can_data[8] = {0U};
    can_data[0] = address & 0x00FF;
    can_data[1] = address >> 8;
    can_data[4] = (uint8_t)data;
    (void)Robstride_SendBytes(device_info->phcan, device_info->device_id, CMD_RAM_WRITE, device_info->master_id, (uint8_t *)can_data, sizeof(can_data));
}

HAL_StatusTypeDef Robstride_WriteIntDataPriority(Robstride_DeviceInfo *const device_info,
                                                  const uint16_t address,
                                                  const int data) {
    uint8_t can_data[8] = {0U};
    can_data[0] = address & 0x00FFU;
    can_data[1] = (uint8_t)(address >> 8);
    can_data[4] = (uint8_t)data;
    return Robstride_SendPriorityBytes(device_info->phcan,
                                       device_info->device_id,
                                       CMD_RAM_WRITE,
                                       device_info->master_id,
                                       can_data,
                                       sizeof(can_data));
}

HAL_StatusTypeDef Robstride_SendBytes(CAN_HandleTypeDef *const phcan,
                                      const uint8_t motor_id,
                                      const uint8_t cmd_id,
                                      const uint16_t option,
                                      const uint8_t *const bytes,
                                      const uint32_t size) {
    /* Runtime CAN congestion must not enter Error_Handler(). */
    return _Robstride_SendBytesToQueue(phcan, motor_id, cmd_id, option,
                                       bytes, size, false);
}

HAL_StatusTypeDef Robstride_SendPriorityBytes(CAN_HandleTypeDef *const phcan,
                                               const uint8_t motor_id,
                                               const uint8_t cmd_id,
                                               const uint16_t option,
                                               const uint8_t *const bytes,
                                               const uint32_t size) {
    return _Robstride_SendBytesToQueue(phcan, motor_id, cmd_id, option,
                                       bytes, size, true);
}

void Robstride_WhenTxMailboxCompleteCallbackCalled(CAN_HandleTypeDef *const phcan) {
    if (_robstride_phcan_global != phcan) return;
    ++robstride_rate_counters.tx_complete;
    (void)_Robstride_PopSendTx8Bytes(phcan);
}

void Robstride_WhenTxMailboxAbortCallbackCalled(CAN_HandleTypeDef *const phcan) {
    if (_robstride_phcan_global != phcan) return;
    (void)_Robstride_PopSendTx8Bytes(phcan);
}

void Robstride_WhenCANErrorCallbackCalled(CAN_HandleTypeDef *const phcan)
{
    if (_robstride_phcan_global != phcan) return;

    const uint32_t primask = __get_PRIMASK();
    __disable_irq();
    ++robstride_can_error_count;
    robstride_can_error_code |= HAL_CAN_GetError(phcan);
    __set_PRIMASK(primask);

    /* A mailbox may have become available after an aborted/error frame. */
    (void)_Robstride_PopSendTx8Bytes(phcan);
}

uint32_t Robstride_TakeTxRingOverrunCount(void)
{
    return robstride_take_counter(&robstride_tx_ring_overrun_count);
}

uint32_t Robstride_TakeTxErrorCount(void)
{
    return robstride_take_counter(&robstride_tx_error_count);
}

uint32_t Robstride_TakePriorityQueueFullCount(void)
{
    return robstride_take_counter(&robstride_priority_queue_full_count);
}

uint32_t Robstride_TakeCanErrorCount(void)
{
    return robstride_take_counter(&robstride_can_error_count);
}

uint32_t Robstride_TakeCanErrorCode(void)
{
    return robstride_take_error_code();
}

void Get_Robstride_MCUID(const uint8_t rxData[], uint8_t device_id) {
    memcpy(&_robstride_feedback_data_raw_global[device_id].mcu_id, &rxData[0], 8);
    robstride_fb_data_global[device_id].mcu_id = _robstride_feedback_data_raw_global[device_id].mcu_id;
    return;
}

void Robstride_SetCANID(Robstride_DeviceInfo *const device_info, const uint8_t new_id) {
    const uint8_t can_data[8] = { 0x00 };
    const uint16_t option = new_id << 8 | device_info->master_id;
    Robstride_SendBytes(device_info->phcan, device_info->device_id, CMD_CHANGE_CAN_ID, option, (uint8_t *)can_data, sizeof(can_data));
    device_info->device_id = new_id;
}

static void Robstride_set_fb_data_raw(const uint32_t ExtID, const uint8_t rxData[], const uint8_t device_id) {
    if (device_id >= 129U) {
        return;
    }

    _robstride_feedback_data_raw_global[device_id]._get_counter += 1;
    if (_robstride_feedback_data_raw_global[device_id]._get_counter > 128) {
        _robstride_feedback_data_raw_global[device_id]._get_counter = 3; // overflow対策
    }
    _robstride_feedback_data_raw_global[device_id].pos = rxData[1] | rxData[0] << 8;
    _robstride_feedback_data_raw_global[device_id].vel = rxData[3] | rxData[2] << 8;
    _robstride_feedback_data_raw_global[device_id].torque = rxData[5] | rxData[4] << 8;
    _robstride_feedback_data_raw_global[device_id].temp = rxData[7] | rxData[6] << 8;

    robstride_fb_data_global[device_id].device_id = device_id;
    robstride_fb_data_global[device_id].get_flag = (_robstride_feedback_data_raw_global[device_id]._get_counter > 2);
    const uint8_t mode_status = (ExtID >> 22) & 0x03; // bit22と23を抽出
    robstride_fb_data_global[device_id].mode_status = mode_status;

    switch (robstride_fb_data_global[device_id].device) {
        case Robstride_02:
            robstride_fb_data_global[device_id].position = uint_to_float(_robstride_feedback_data_raw_global[device_id].pos, P_MIN_ROBSTRIDE02, P_MAX_ROBSTRIDE02) * robstride_fb_data_global[device_id].quant_per_rot * robstride_fb_data_global[device_id].plus_minus;
            robstride_fb_data_global[device_id].position += robstride_fb_data_global[device_id].offset_pos;
            robstride_fb_data_global[device_id].velocity = uint_to_float(_robstride_feedback_data_raw_global[device_id].vel, V_MIN_ROBSTRIDE02, V_MAX_ROBSTRIDE02) * robstride_fb_data_global[device_id].quant_per_rot * robstride_fb_data_global[device_id].plus_minus;
            robstride_fb_data_global[device_id].torque = uint_to_float(_robstride_feedback_data_raw_global[device_id].torque, T_MIN_ROBSTRIDE02, T_MAX_ROBSTRIDE02);
            break;
        case Robstride_04:
            robstride_fb_data_global[device_id].position = uint_to_float(_robstride_feedback_data_raw_global[device_id].pos, P_MIN_ROBSTRIDE04, P_MAX_ROBSTRIDE04) * robstride_fb_data_global[device_id].quant_per_rot * robstride_fb_data_global[device_id].plus_minus;
            robstride_fb_data_global[device_id].position += robstride_fb_data_global[device_id].offset_pos;
            robstride_fb_data_global[device_id].velocity = uint_to_float(_robstride_feedback_data_raw_global[device_id].vel, V_MIN_ROBSTRIDE04, V_MAX_ROBSTRIDE04) * robstride_fb_data_global[device_id].quant_per_rot * robstride_fb_data_global[device_id].plus_minus;
            robstride_fb_data_global[device_id].torque = uint_to_float(_robstride_feedback_data_raw_global[device_id].torque, T_MIN_ROBSTRIDE04, T_MAX_ROBSTRIDE04);
            break;

        case Robstride_05_Edu:
            robstride_fb_data_global[device_id].position = uint_to_float(_robstride_feedback_data_raw_global[device_id].pos, P_MIN_ROBSTRIDE05, P_MAX_ROBSTRIDE05) * robstride_fb_data_global[device_id].quant_per_rot * robstride_fb_data_global[device_id].plus_minus;
            robstride_fb_data_global[device_id].position += robstride_fb_data_global[device_id].offset_pos;
            robstride_fb_data_global[device_id].velocity = uint_to_float(_robstride_feedback_data_raw_global[device_id].vel, V_MIN_ROBSTRIDE05, V_MAX_ROBSTRIDE05) * robstride_fb_data_global[device_id].quant_per_rot * robstride_fb_data_global[device_id].plus_minus;
            robstride_fb_data_global[device_id].torque = uint_to_float(_robstride_feedback_data_raw_global[device_id].torque, T_MIN_ROBSTRIDE05, T_MAX_ROBSTRIDE05);
            break;
        default:
            break;
    }
    //    printf("id: %u, pos: %f, vel: %f, torque: %f\n\r",
    //           device_id,
    //           robstride_fb_data_global[device_id].position,
    //           robstride_fb_data_global[device_id].velocity,
    //           robstride_fb_data_global[device_id].torque);
    robstride_fb_data_global[device_id].temperature = (int)((float)(_robstride_feedback_data_raw_global[device_id].temp) / 10.0);
    robstride_standard_feedback[device_id]=(Robstride_StandardFeedback){
        .position=robstride_fb_data_global[device_id].position,
        .velocity=robstride_fb_data_global[device_id].velocity,
        .torque=robstride_fb_data_global[device_id].torque*robstride_fb_data_global[device_id].plus_minus,
        .tick=HAL_GetTick(), .valid=true};
    ++robstride_feedback_sequence[device_id];
    if (device_id==1U || device_id==2U) ++robstride_rate_counters.type2_rx[device_id-1U];
}

void Robstride_WhenCANRxFifo0MsgPending(CAN_HandleTypeDef *const phcan) {
    if (_robstride_phcan_global != phcan) return;
    CAN_RxHeaderTypeDef rxHeader;
    uint8_t rxData[8];
    if (HAL_CAN_GetRxMessage(phcan, CAN_RX_FIFO0, &rxHeader, rxData) != HAL_OK) {
        return;
    }
    if (rxHeader.IDE != CAN_ID_EXT) return;

    uint8_t motor_id = 0;
    uint32_t ExtId = rxHeader.ExtId;
    if (ExtId >= 0x00FE && ExtId <= 0x7FFE) {
        motor_id = (uint8_t)(ExtId >> 8);
        //    printf("response1 from motor from %d\n\r", (int)motor_id);
        Get_Robstride_MCUID(rxData, motor_id);
    } else if ((ExtId & 0xFF000000U) == 0x02000000U) {
        // uint32_t master_id = (uint8_t)(ExtId & 0xFF);
        motor_id = (uint8_t)((ExtId >> 8) & 0xFF);
        Robstride_set_fb_data_raw(ExtId, rxData, motor_id);
        //    printf("response2 from motor from %d to %d\n\r", (int)motor_id, (int)master_id);
    } else if ((ExtId & 0xFF000000U) == 0x11000000U) {
        // uint32_t master_id = (uint8_t)(ExtId & 0xFF);
        motor_id = (uint8_t)((ExtId >> 8) & 0xFF);
        Robstride_ProcessParameterFrame(ExtId, rxData, motor_id);
        // printf("response3 from motor from %d to %d\n\r", (int)motor_id, (int)master_id);
    } else if ((ExtId & 0xFF000000U) == 0x15000000U) {
        // Fault response: motor ID is in bits 8..15; the low byte is master ID.
        motor_id = (uint8_t)((ExtId >> 8) & 0xFF);
        Robstride_ProcessFault(rxData, motor_id);
        // printf("response4 from motor from %d to %d\n\r", (int)motor_id, (int)master_id);
    }
    // printf("got response from %d\n\r", (int)motor_id);
}

void Robstride_WhenCANRxFifo1MsgPending(CAN_HandleTypeDef *const phcan) {
    if (_robstride_phcan_global != phcan) return;
    CAN_RxHeaderTypeDef rxHeader;
    uint8_t rxData[8];
    if (HAL_CAN_GetRxMessage(phcan, CAN_RX_FIFO1, &rxHeader, rxData) != HAL_OK) {
        return;
    }
    if (rxHeader.IDE != CAN_ID_EXT) return;

    uint8_t motor_id = 0;
    uint32_t ExtId = rxHeader.ExtId;
    if (ExtId >= 0x00FE && ExtId <= 0x7FFE) {
        motor_id = (uint8_t)(ExtId >> 8);
        // printf("response1 from motor from %d\n\r", (int)motor_id);
        Get_Robstride_MCUID(rxData, motor_id);
    } else if ((ExtId & 0xFF000000U) == 0x02000000U) {
        // uint32_t master_id = (uint8_t)(ExtId & 0xFF);
        motor_id = (uint8_t)((ExtId >> 8) & 0xFF);
        Robstride_set_fb_data_raw(ExtId, rxData, motor_id);
        // printf("response2 from motor from %d to %d\n\r", (int)motor_id, (int)master_id);
    } else if ((ExtId & 0xFF000000U) == 0x11000000U) {
        // uint32_t master_id = (uint8_t)(ExtId & 0xFF);
        motor_id = (uint8_t)((ExtId >> 8) & 0xFF);
        Robstride_ProcessParameterFrame(ExtId, rxData, motor_id);
        // printf("response3 from motor from %d to %d\n\r", (int)motor_id, (int)master_id);
    } else if ((ExtId & 0xFF000000U) == 0x15000000U) {
        // Fault response: motor ID is in bits 8..15; the low byte is master ID.
        motor_id = (uint8_t)((ExtId >> 8) & 0xFF);
        Robstride_ProcessFault(rxData, motor_id);
        // printf("response4 from motor from %d to %d\n\r", (int)motor_id, (int)master_id);
    }
    // printf("got response from %d\n\r", (int)motor_id);
}

void Init_Robstride_CAN_System(CAN_HandleTypeDef *const phcan) { // CAN初期化
    _robstride_phcan_global = phcan;
    CAN_FilterTypeDef sFilterConfig;

    uint32_t FilterID, FilterMaskID;

    // フィルタバンク設定
    sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
    sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
    sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO1;
    sFilterConfig.FilterActivation = ENABLE;
    sFilterConfig.SlaveStartFilterBank = 14;

    if (phcan->Instance == CAN1 || phcan->Instance == CAN3) {
        // CAN1 or 3 使用時のフィルタを設定

        // Get device ID (Communication type 0) のフィルタを FIFO 0 に設定
        FilterID = (0x00000000 | 0xFE) << 3;
        FilterMaskID = (0x1F000000 | 0xFF) << 3;
        sFilterConfig.FilterBank = 2;
        sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0;
        sFilterConfig.FilterIdHigh = FilterID >> 16;
        sFilterConfig.FilterMaskIdHigh = FilterMaskID >> 16;
        sFilterConfig.FilterIdLow = FilterID;
        sFilterConfig.FilterMaskIdLow = FilterMaskID;
        if (HAL_CAN_ConfigFilter(phcan, &sFilterConfig) != HAL_OK) {
            Error_Handler();
        }

        // Response motor feedback (Communication type 2) のフィルタを FIFO 1 に設定
        FilterID = 0x02000000 << 3;
        FilterMaskID = 0x1F000000 << 3;
        sFilterConfig.FilterBank = 3;
        sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO1;
        sFilterConfig.FilterIdHigh = FilterID >> 16;
        sFilterConfig.FilterMaskIdHigh = FilterMaskID >> 16;
        sFilterConfig.FilterIdLow = FilterID;
        sFilterConfig.FilterMaskIdLow = FilterMaskID;
        if (HAL_CAN_ConfigFilter(phcan, &sFilterConfig) != HAL_OK) {
            Error_Handler();
        }

        // Single parameter read (Communication type 17) のフィルタを FIFO 0 に設定
        FilterID = 0x11000000 << 3;
        FilterMaskID = 0x1F000000 << 3;
        sFilterConfig.FilterBank = 4;
        sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0;
        sFilterConfig.FilterIdHigh = FilterID >> 16;
        sFilterConfig.FilterMaskIdHigh = FilterMaskID >> 16;
        sFilterConfig.FilterIdLow = FilterID;
        sFilterConfig.FilterMaskIdLow = FilterMaskID;
        if (HAL_CAN_ConfigFilter(phcan, &sFilterConfig) != HAL_OK) {
            Error_Handler();
        }

        // Fault feedback frame (Communication type 21) のフィルタを FIFO 0 に設定
        FilterID = 0x15000000 << 3;
        FilterMaskID = 0x1F000000 << 3;
        sFilterConfig.FilterBank = 5;
        sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO1;
        sFilterConfig.FilterIdHigh = FilterID >> 16;
        sFilterConfig.FilterMaskIdHigh = FilterMaskID >> 16;
        sFilterConfig.FilterIdLow = FilterID;
        sFilterConfig.FilterMaskIdLow = FilterMaskID;
        if (HAL_CAN_ConfigFilter(phcan, &sFilterConfig) != HAL_OK) {
            Error_Handler();
        }

    } else if (phcan->Instance == CAN2) {
        // CAN2 使用時のフィルタを設定

        // Get device ID (Communication type 0) のフィルタを FIFO 0 に設定
        FilterID = (0x00000000 | 0xFE) << 3;
        FilterMaskID = (0x1F000000 | 0xFF) << 3;
        sFilterConfig.FilterBank = 15;
        sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0;
        sFilterConfig.FilterIdHigh = FilterID >> 16;
        sFilterConfig.FilterMaskIdHigh = FilterMaskID >> 16;
        sFilterConfig.FilterIdLow = FilterID;
        sFilterConfig.FilterMaskIdLow = FilterMaskID;
        if (HAL_CAN_ConfigFilter(phcan, &sFilterConfig) != HAL_OK) {
            Error_Handler();
        }

        // Response motor feedback (Communication type 2) のフィルタを FIFO 1 に設定
        FilterID = 0x02000000 << 3;
        FilterMaskID = 0x1F000000 << 3;
        sFilterConfig.FilterBank = 16;
        sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO1;
        sFilterConfig.FilterIdHigh = FilterID >> 16;
        sFilterConfig.FilterMaskIdHigh = FilterMaskID >> 16;
        sFilterConfig.FilterIdLow = FilterID;
        sFilterConfig.FilterMaskIdLow = FilterMaskID;
        if (HAL_CAN_ConfigFilter(phcan, &sFilterConfig) != HAL_OK) {
            Error_Handler();
        }

        // Single parameter read (Communication type 17) のフィルタを FIFO 0 に設定
        FilterID = 0x11000000 << 3;
        FilterMaskID = 0x1F000000 << 3;
        sFilterConfig.FilterBank = 17;
        sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0;
        sFilterConfig.FilterIdHigh = FilterID >> 16;
        sFilterConfig.FilterMaskIdHigh = FilterMaskID >> 16;
        sFilterConfig.FilterIdLow = FilterID;
        sFilterConfig.FilterMaskIdLow = FilterMaskID;
        if (HAL_CAN_ConfigFilter(phcan, &sFilterConfig) != HAL_OK) {
            Error_Handler();
        }

        // Fault feedback frame (Communication type 21) のフィルタを FIFO 0 に設定
        FilterID = 0x15000000 << 3;
        FilterMaskID = 0x1F000000 << 3;
        sFilterConfig.FilterBank = 18;
        sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO1;
        sFilterConfig.FilterIdHigh = FilterID >> 16;
        sFilterConfig.FilterMaskIdHigh = FilterMaskID >> 16;
        sFilterConfig.FilterIdLow = FilterID;
        sFilterConfig.FilterMaskIdLow = FilterMaskID;
        if (HAL_CAN_ConfigFilter(phcan, &sFilterConfig) != HAL_OK) {
            Error_Handler();
        }

    } else {
        printf("CAN Instance Error\n");
        Error_Handler();
    }

    if (HAL_CAN_Start(phcan) != HAL_OK) {
        printf(" -> Start Error CAN_Robstride\n");
        Error_Handler();
    }

    if (HAL_CAN_ActivateNotification(phcan, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK) {
        printf(" -> FIFO0 CAN_Activation error\n\r");
        Error_Handler();
    }

    if (HAL_CAN_ActivateNotification(phcan, CAN_IT_RX_FIFO1_MSG_PENDING) != HAL_OK) {
        printf(" -> FIFO1 CAN_Activation error1\n\r");
        Error_Handler();
    }

    if (HAL_CAN_ActivateNotification(phcan, CAN_IT_TX_MAILBOX_EMPTY) != HAL_OK) {
        printf(" -> CAN_Activation error2\n\r");
        Error_Handler();
    }

    /* Error/FIFO overrun通知はカウンタへ記録し、タスク側で警告する。 */
    if (HAL_CAN_ActivateNotification(
            phcan,
            CAN_IT_ERROR_WARNING |
            CAN_IT_ERROR_PASSIVE |
            CAN_IT_BUSOFF |
            CAN_IT_LAST_ERROR_CODE |
            CAN_IT_ERROR |
            CAN_IT_RX_FIFO0_OVERRUN |
            CAN_IT_RX_FIFO1_OVERRUN) != HAL_OK) {
        printf(" -> CAN_Error_Activation error\n\r");
        Error_Handler();
    }

    for (uint8_t i = 0; i < 129; i++) { // init fb_data_raw
        _robstride_feedback_data_raw_global[i].pos = 0;
        _robstride_feedback_data_raw_global[i]._rot_num = 0;
        _robstride_feedback_data_raw_global[i].vel = 0;
        _robstride_feedback_data_raw_global[i].torque = 0;
        _robstride_feedback_data_raw_global[i].temp = 0;
        _robstride_feedback_data_raw_global[i]._get_counter = 0;
        robstride_fb_data_global[i].position = 0;
        robstride_fb_data_global[i].velocity = 0;
        robstride_fb_data_global[i].torque = 0;
        robstride_fb_data_global[i].temperature = 0;
        robstride_fb_data_global[i].current = 0;
        robstride_feedback_sequence[i] = 0U;
        robstride_parameter_sequence[i].run_mode = 0U;
        robstride_parameter_sequence[i].iq_ref = 0U;
        robstride_parameter_sequence[i].speed_ref = 0U;
        robstride_parameter_sequence[i].loc_ref = 0U;
        robstride_parameter_sequence[i].cur_kp = 0U;
        robstride_parameter_sequence[i].cur_ki = 0U;
        robstride_parameter_sequence[i].cur_filt_gain = 0U;
        robstride_parameter_master_id[i] = 0U;
        robstride_parameter_master_id_valid[i] = 0U;
    }
}

/**
 * @brief モーターから複数のパラメータを個別に読み出し、フィードバックデータを更新します。
 * @note 【非推奨】この関数は、モーターに対してパラメータ読み出しコマンド（Type 17）を個別に送信します。
 * しかし、以下の制御コマンドを送信した際には、モーターはその応答として標準フィードバック（Type 2）を自動的に返信します。
 * - Type 1: 操作制御モード命令 (Robstride_SetTargetなど)
 * - Type 3: モーター運転開始 (Robstride_ControlEnable)
 * - Type 4: モーター運転停止 (Robstride_ControlDisable)
 * - Type 6: ゼロ点設定
 * - Type 18: パラメータ書き込み
 * - Type 22: データ保存
 *
 * したがって、制御ループ内で上記のコマンドを周期的に送信している場合、
 * この関数を別途呼び出す必要はありません。
 * むしろ、異なる2系統のフィードバックを非同期に取得することになり、
 *　Posデータが１から２度ずれるため、使用は推奨されません。
 * 代わりに`Read_Robstride_FeedbackData`を使用してください。
 * また、標準フィードバックで更新されるデータは位置、速度、トルクなので、これら以外のパラメーターが必要な場合は、
 * それぞれで個別に読み出しコマンドを送信してください。
 * @param device_info Robstrideデバイス情報構造体へのポインタ
 * @return Robstride_FeedbackData 更新されたフィードバックデータ
 */
Robstride_FeedbackData Get_Robstride_FeedbackData(Robstride_DeviceInfo *const device_info) {
    Robstride_RequestReadParameter(device_info, ADDR_MECH_POS);
    Robstride_RequestReadParameter(device_info, ADDR_MECH_VEL);
    Robstride_RequestReadParameter(device_info, ADDR_IQF);
    uint8_t device_id = device_info->device_id;
    robstride_fb_data_global[device_id].device_id = device_id;
    return robstride_fb_data_global[device_id];
}
Robstride_FeedbackData Read_Robstride_FeedbackData(Robstride_DeviceInfo *const device_info) {
    uint8_t device_id = device_info->device_id;
    robstride_fb_data_global[device_id].device_id = device_id;
    return robstride_fb_data_global[device_id];
}

bool Robstride_ReadMeasuredPosition(const Robstride_DeviceInfo *device, float *position, uint32_t *tick)
{
    if (!device || device->device_id >= 129U || !position || !tick) return false;
    if (Robstride_UsesStandardFeedback(device)) {
        Robstride_StandardFeedback feedback;
        const bool valid=Robstride_ReadStandardFeedback(device,&feedback);
        *position=feedback.position; *tick=feedback.tick;
        return valid;
    }
    uint32_t mask = __get_PRIMASK();
    __disable_irq();
    const uint8_t id = device->device_id;
    bool valid = arm_position_valid[id];
    *position = arm_measured_position[id];
    *tick = arm_position_tick[id];
    __set_PRIMASK(mask);
    return valid;
}

uint32_t Robstride_GetFeedbackSequence(const Robstride_DeviceInfo *const device_info)
{
    if (device_info == NULL || device_info->device_id >= 129U) {
        return 0U;
    }

    const uint32_t primask = __get_PRIMASK();
    uint32_t sequence;
    __disable_irq();
    sequence = robstride_feedback_sequence[device_info->device_id];
    __set_PRIMASK(primask);
    return sequence;
}

uint32_t Robstride_GetParameterSequence(const Robstride_DeviceInfo *const device_info,
                                        const uint16_t address)
{
    if (device_info == NULL || device_info->device_id >= 129U) {
        return 0U;
    }

    const uint32_t primask = __get_PRIMASK();
    uint32_t sequence = 0U;
    __disable_irq();
    switch (address) {
        case ADDR_RUN_MODE:
            sequence = robstride_parameter_sequence[device_info->device_id].run_mode;
            break;
        case ADDR_IQ_REF:
            sequence = robstride_parameter_sequence[device_info->device_id].iq_ref;
            break;
        case ADDR_SPEED_REF:
            sequence = robstride_parameter_sequence[device_info->device_id].speed_ref;
            break;
        case ADDR_LOC_REF:
            sequence = robstride_parameter_sequence[device_info->device_id].loc_ref;
            break;
        case ADDR_CURRENT_KP:
            sequence = robstride_parameter_sequence[device_info->device_id].cur_kp; break;
        case ADDR_CURRENT_KI:
            sequence = robstride_parameter_sequence[device_info->device_id].cur_ki; break;
        case ADDR_CURRENT_FILTER_GAIN:
            sequence = robstride_parameter_sequence[device_info->device_id].cur_filt_gain; break;
        default:
            break;
    }
    __set_PRIMASK(primask);
    return sequence;
}

void Robstride_ProcessParameterFrame(const uint32_t ExtID,
                                     const uint8_t rxData[],
                                     const uint8_t device_id)
{
    if (device_id >= 129U) {
        return;
    }

    /* For a Type 17 reply, bits 23..16 are the read result: 0 means success,
     * 1 means the requested parameter could not be read.  Do not update the
     * cache or wake a service waiter from a failed parameter transaction. */
    if (((ExtID >> 16) & 0xFFU) != 0U) {
        return;
    }

    if (robstride_parameter_master_id_valid[device_id] != 0U &&
        (uint8_t)(ExtID & 0xFFU) != robstride_parameter_master_id[device_id]) {
        return;
    }
    Robstride_ProcessParameter(rxData, device_id);
}

void Robstride_ProcessParameter(const uint8_t rxData[], const uint8_t device_id) {
    if (device_id >= 129U) {
        return;
    }

    const uint16_t address = rxData[0] | rxData[1] << 8;
    uint8_t uint8_data;
    // int16_t int16_data;
    float float_data;
    uint16_t uint16_data;
    uint32_t uint32_data;

    switch (address) {
        case ADDR_RUN_MODE: // 0x7005
            memcpy(&uint8_data, &rxData[4], sizeof(uint8_data));
            robstride_fb_data_global[device_id].run_mode = uint8_data;
            ++robstride_parameter_sequence[device_id].run_mode;
            break;
        case ADDR_IQ_REF: // 0x7006
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].iq_ref = float_data;
            ++robstride_parameter_sequence[device_id].iq_ref;
            break;
        case ADDR_SPEED_REF: // 0x700A
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].spd_ref = float_data;
            ++robstride_parameter_sequence[device_id].speed_ref;
            break;
        case ADDR_LIMIT_TORQUE: // 0x700B
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].limit_torque = float_data;
            break;
        case ADDR_CURRENT_KP: // 0x7010
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].cur_kp = float_data;
            ++robstride_parameter_sequence[device_id].cur_kp;
            break;
        case ADDR_CURRENT_KI: // 0x7011
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].cur_ki = float_data;
            ++robstride_parameter_sequence[device_id].cur_ki;
            break;
        case ADDR_CURRENT_FILTER_GAIN: // 0x7014
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].cur_filt_gain = float_data;
            ++robstride_parameter_sequence[device_id].cur_filt_gain;
            break;
        case ADDR_LOC_REF: // 0x7016
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].loc_ref = float_data;
            ++robstride_parameter_sequence[device_id].loc_ref;
            break;
        case ADDR_LIMIT_SPEED: // 0x7017
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].limit_spd = float_data;
            break;
        case ADDR_LIMIT_CURRENT: // 0x7018
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].limit_cur = float_data;
            break;
        case ADDR_MECH_POS:
            if (device_id==1U || device_id==2U) ++robstride_rate_counters.position_rx[device_id-1U];
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].position = float_data * robstride_fb_data_global[device_id].quant_per_rot * robstride_fb_data_global[device_id].plus_minus;
            robstride_fb_data_global[device_id].position += robstride_fb_data_global[device_id].offset_pos;
            arm_measured_position[device_id] = robstride_fb_data_global[device_id].position;
            arm_position_tick[device_id] = HAL_GetTick();
            arm_position_valid[device_id] = true;
            // printf("motor%d: pos %f\n\r", (int)device_id, robstride_fb_data_global[device_id].position);
            _robstride_feedback_data_raw_global[device_id]._get_counter += 1;
            if (_robstride_feedback_data_raw_global[device_id]._get_counter > 128) {
                _robstride_feedback_data_raw_global[device_id]._get_counter = 3; // overflow対策
            }
            robstride_fb_data_global[device_id].get_flag = (_robstride_feedback_data_raw_global[device_id]._get_counter > 2);
            break;
        case ADDR_IQF:
            if (device_id==1U || device_id==2U) ++robstride_rate_counters.iq_rx[device_id-1U];
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].current = float_data * robstride_fb_data_global[device_id].plus_minus;
            _robstride_feedback_data_raw_global[device_id]._get_counter += 1;
            // printf("motor%d: current %f\n\r", (int)device_id, robstride_fb_data_global[device_id].current);
            if (_robstride_feedback_data_raw_global[device_id]._get_counter > 128) {
                _robstride_feedback_data_raw_global[device_id]._get_counter = 3; // overflow対策
            }
            robstride_fb_data_global[device_id].get_flag = (_robstride_feedback_data_raw_global[device_id]._get_counter > 2);
            break;
        case ADDR_MECH_VEL:
            if (device_id==1U || device_id==2U) ++robstride_rate_counters.velocity_rx[device_id-1U];
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].velocity = float_data * robstride_fb_data_global[device_id].quant_per_rot * robstride_fb_data_global[device_id].plus_minus;
            // printf("motor%d: vel %f\n\r", (int)device_id, robstride_fb_data_global[device_id].velocity);
            _robstride_feedback_data_raw_global[device_id]._get_counter += 1;
            if (_robstride_feedback_data_raw_global[device_id]._get_counter > 128) {
                _robstride_feedback_data_raw_global[device_id]._get_counter = 3; // overflow対策
            }
            robstride_fb_data_global[device_id].get_flag = (_robstride_feedback_data_raw_global[device_id]._get_counter > 2);
            break;
        case ADDR_VBUS: // 0x701C
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].vbus = float_data;
            break;
        case ADDR_LOC_KP: // 0x701E
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].loc_kp = float_data;
            break;
        case ADDR_SPD_KP: // 0x701F
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].spd_kp = float_data;
            break;
        case ADDR_SPD_KI: // 0x7020
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].spd_ki = float_data;
            break;
        case ADDR_SPD_FILTER_GAIN: // 0x7021
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].spd_filt_gain = float_data;
            break;
        case ADDR_ACC_RAD: // 0x7022
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].acc_rad = float_data;
            break;
        case ADDR_VEL_MAX_PP: // 0x7024
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].vel_max_pp = float_data;
            break;
        case ADDR_ACC_SET_PP: // 0x7025
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].acc_set_pp = float_data;
            break;
        case ADDR_EPSCAN_TIME: // 0x7026
            memcpy(&uint16_data, &rxData[4], sizeof(uint16_data));
            robstride_fb_data_global[device_id].epscan_time = uint16_data;
            break;
        case ADDR_CAN_TIMEOUT: // 0x7028
            memcpy(&uint32_data, &rxData[4], sizeof(uint32_data));
            robstride_fb_data_global[device_id].can_timeout = uint32_data;
            break;
        case ADDR_ZERO_STA: // 0x7029
            memcpy(&uint8_data, &rxData[4], sizeof(uint8_data));
            robstride_fb_data_global[device_id].zero_sta = uint8_data;
            break;
        case ADDR_ADD_OFFSET: // 0x702B
            memcpy(&float_data, &rxData[4], sizeof(float_data));
            robstride_fb_data_global[device_id].add_offset = float_data;
            break;
        default:
            break;
    }
}

void Robstride_ProcessFault(const uint8_t rxData[], const uint8_t device_id) {
    if (device_id >= 129U) {
        return;
    }

    const uint32_t fault_code = ((uint32_t)rxData[0]) |
                                ((uint32_t)rxData[1] << 8) |
                                ((uint32_t)rxData[2] << 16) |
                                ((uint32_t)rxData[3] << 24);
    const uint32_t warning_code = ((uint32_t)rxData[4]) |
                                  ((uint32_t)rxData[5] << 8) |
                                  ((uint32_t)rxData[6] << 16) |
                                  ((uint32_t)rxData[7] << 24);
    if (fault_code == robstride_last_fault_code[device_id] &&
        warning_code == robstride_last_warning_code[device_id]) {
        return;
    }
    robstride_last_fault_code[device_id] = fault_code;
    robstride_last_warning_code[device_id] = warning_code;

    if ((fault_code & 0x00000001U) != 0U) {
        printf("motor%d:Motor over temperature fault\n\r", (int)device_id);
    }
    if ((fault_code & 0x00000002U) != 0U) {
        printf("motor%d:Driver chip failure\n\r", (int)device_id);
    }
    if ((fault_code & 0x00000004U) != 0U) {
        printf("motor%d:Undervoltage fault\n\r", (int)device_id);
    }
    if ((fault_code & 0x00000008U) != 0U) {
        printf("motor%d:Overvoltage fault\n\r", (int)device_id);
    }
    if ((fault_code & 0x00000010U) != 0U) {
        printf("motor%d:B-phase current sampling overcurrent\n\r", (int)device_id);
    }
    if ((fault_code & 0x00000020U) != 0U) {
        printf("motor%d:C-phase current sampling overcurrent\n\r", (int)device_id);
    }
    if ((fault_code & 0x00000080U) != 0U) {
        printf("motor%d:Encoder not calibrated\n\r", (int)device_id);
    }
    if ((fault_code & 0x00000100U) != 0U) {
        printf("motor%d:Overload fault\n\r", (int)device_id);
    }
    if ((fault_code & 0x00010000U) != 0U) {
        printf("motor%d:A-phase current sampling overcurrent\n\r", (int)device_id);
    }
    if ((warning_code & 0x00000001U) != 0U) {
        printf("motor%d:Motor over temperature warning\n\r", (int)device_id);
    }
}

void Robstride_fb_init(Robstride_DeviceInfo *const device_info) {
    robstride_standard_feedback[device_info->device_id].valid=false;
    arm_position_valid[device_info->device_id] = false;
    _Robstride_RegisterParameterMasterId(device_info);
    if (device_info->ctrl_param.rotation == ROBSTRIDE_ROT_CW) {
        robstride_fb_data_global[device_info->device_id].plus_minus = -1;
    } else {
        robstride_fb_data_global[device_info->device_id].plus_minus = 1;
    }
    robstride_fb_data_global[device_info->device_id].quant_per_rot = device_info->ctrl_param.quant_per_rot;
    robstride_fb_data_global[device_info->device_id].offset_pos = device_info->ctrl_param.offset_pos;
    robstride_fb_data_global[device_info->device_id].device = device_info->device;
}
